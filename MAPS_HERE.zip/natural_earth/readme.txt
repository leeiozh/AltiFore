place this folder to

venv/lib/python3.11/site-packages/cartopy/data/shapefiles/

or smth similar if you use anaconda
